/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 Demonstrates using a custom back button image with no chevron and
  not text.
 */

@import UIKit;

@interface CustomBackButtonViewController : UITableViewController
@end
