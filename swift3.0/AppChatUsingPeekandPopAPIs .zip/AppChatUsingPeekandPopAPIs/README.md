# AppChat: Using Peek and Pop APIs

This sample demonstrates how to incorporate 3D Touch into an iOS App. It makes use of Home Screen Quick Actions (both static and dynamic), Peek and Pop, Peek Actions and UIPreviewInteraction.

## Requirements

### Build

Xcode 8.0 or later; iOS 10.0 SDK or later

### Runtime

iOS 10.0 or later

Copyright (C) 2016 Apple Inc. All rights reserved.
